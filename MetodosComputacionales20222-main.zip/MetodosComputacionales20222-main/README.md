# Métodos Computacionales - 2022-2

### Entornos de programación académica en línea:
* [![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/asegura4488/MetodosComputacionales20222/main)
* Azure cloud service de [Uniandes ![Uniandes](imagenes/andes_32px.png)](http://facciencias.az.uniandes.edu.co/jhub/)

## Material del curso Métodos Computacionales de Uniandes

> Nota: el material aquí publicado es basado del [proyecto académico de enseñanza de Física Computacional ![ComputoCienciasUniandes](imagenes/GitHub-Mark-32px.png)](http://computocienciasuniandes.github.io/) liderado por el Profesor Jaime Ernesto Forero

**Universidad de los Andes | Vigilada Mineducación
Reconocimiento como Universidad: Decreto 1297 del 30 de mayo de 1964.
Reconocimiento personería jurídica: Resolución 28 del 23 de febrero de 1949 Minjusticia.**

*Carrera 1 18A-10, Bloque Ip. Bogota - Colombia. A.A. 4976-12340.*   
*Telephone +571 3324500.*
*Fax +571 3324516*

Universidad de los Andes
Facultad de Ciencias
Departamento de Física
